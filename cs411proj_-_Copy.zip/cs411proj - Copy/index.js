// index.js
const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2/promise');
const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.json());
app.use(express.static('public')); // serve HTML, CSS, JS from public folder

// MySQL connection
const dbConfig = {
    host: 'localhost',
    user: 'root',
    password: '', //MSQL password
    database: 'SocialMediadb'
};
console.log("THIS IS THE FILE BEING RUN");
console.log("DB USER:", dbConfig.user);
let pool;
(async () => {
    pool = await mysql.createPool(dbConfig);
    console.log('Connected to MySQL database!');
})();


// GET all posts

app.get('/posts', async (req, res) => {
    try {
        const [rows] = await pool.query(
            `SELECT post_id, user_id, content, created_at, last_updated 
             FROM Post 
             ORDER BY created_at DESC`
        );

        // Ensure rows is always an array
        res.json(Array.isArray(rows) ? rows : []);
        console.log('Fetched posts:', rows);
    } catch (err) {
        console.error('Error fetching posts:', err);
        res.status(500).json({ error: 'Failed to fetch posts', details: err.message });
    }
});

// CREATE a post

app.post('/posts', async (req, res) => {
    try {
        const { username, content } = req.body;

        if (!username || !content) {
            return res.status(400).json({ error: 'Username and content required' });
        }

        //  Check if user exists, otherwise insert
        let [users] = await pool.query('SELECT user_id FROM User WHERE username = ?', [username]);
        let user_id;
        if (users.length > 0) {
            user_id = users[0].user_id;
        } else {
            const [result] = await pool.query('INSERT INTO User (username) VALUES (?)', [username]);
            user_id = result.insertId;
        }

        //  Insert post
        const [postResult] = await pool.query(
            'INSERT INTO Post (user_id, content) VALUES (?, ?)',
            [user_id, content]
        );

        res.json({ success: true, post_id: postResult.insertId });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Failed to create post' });
    }
});

// UPDATE a post

app.put('/posts/:id', async (req, res) => {
    try {
        const postId = req.params.id;
        const { content } = req.body;

        if (!content) return res.status(400).json({ error: 'Content required' });

        await pool.query('UPDATE Post SET content = ? WHERE post_id = ?', [content, postId]);

        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Failed to update post' });
    }
});


// DELETE all posts

app.delete('/posts', async (req, res) => {
    try {
        await pool.query('DELETE FROM Post');
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Failed to delete posts' });
    }
});

// -----------------------
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
