-- Create the Database
CREATE DATABASE IF NOT EXISTS SocialMediadb;
USE SocialMediadb;


-- Users
CREATE TABLE IF NOT EXISTS User (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL
);

-- Posts
CREATE TABLE IF NOT EXISTS Post (
    post_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES User(user_id)
);

-- Bookmarks
CREATE TABLE IF NOT EXISTS Bookmarks (
    bookmark_id INT AUTO_INCREMENT PRIMARY KEY,
    post_id INT NOT NULL,
    user_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (post_id) REFERENCES Post(post_id),
    FOREIGN KEY (user_id) REFERENCES User(user_id)
);

-- Post Edit History
CREATE TABLE IF NOT EXISTS PostHistory (
    history_id INT AUTO_INCREMENT PRIMARY KEY,
    post_id INT NOT NULL,
    old_content TEXT NOT NULL,
    edited_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (post_id) REFERENCES Post(post_id)
);

-- Trigger: Save Old Content Automatically

DELIMITER //
CREATE TRIGGER save_post_history
BEFORE UPDATE ON Post
FOR EACH ROW
BEGIN
    INSERT INTO PostHistory (post_id, old_content)
    VALUES (OLD.post_id, OLD.content);
END;
//
DELIMITER ;
