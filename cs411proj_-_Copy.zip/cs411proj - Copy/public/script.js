document.addEventListener('DOMContentLoaded', () => {
    // CREATE POST (userpost.html)
    const postForm = document.getElementById('postForm');
    if (postForm) {
        postForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const username = postForm.username.value; // we still need to associate with a user
            const content = postForm.description.value;

            fetch('/posts', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, content })
            })
            .then(res => res.json())
            .then(data => {
                alert('Post created!');
                postForm.reset();
            })
            .catch(err => console.error(err));
        });
    }

    // LOAD POSTS (index.html)
    const postContainer = document.getElementById('postContainer');
    if (postContainer) {

        // make loadPosts global for refresh button
        window.loadPosts = function() {
    fetch('/posts')
        .then(res => res.json())
        .then(posts => {
            // Make sure posts is always an array
            if (!Array.isArray(posts)) posts = [];

            postContainer.innerHTML = '';
            posts.reverse().forEach(post => {
                const div = document.createElement('div');
                div.className = 'post';
                div.innerHTML = `
                    <strong>User ${post.user_id}</strong>
                    <p contenteditable="true" data-id="${post.post_id}">${post.content}</p>
                    <button data-id="${post.post_id}">Save</button>
                `;
                postContainer.appendChild(div);
            });

            // Add save button listeners
            postContainer.querySelectorAll('button').forEach(button => {
                button.addEventListener('click', () => {
                    const postId = button.dataset.id;
                    const newContent = button.previousElementSibling.textContent;

                    fetch('/posts/' + postId, {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ content: newContent })
                    })
                    .then(res => res.json())
                    .then(() => {
                        alert('Post updated!');
                        loadPosts();
                    })
                    .catch(err => console.error(err));
                });
            });
        })
        .catch(err => console.error('Error loading posts:', err));
};


        // initial load
        window.loadPosts();
    }

});
